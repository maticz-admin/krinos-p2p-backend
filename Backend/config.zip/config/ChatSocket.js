import { Server } from 'socket.io';
import { createroom, lefttrade, sendmessage } from '../controllers/P2PCONTROLLER/OrderchatController';

let socketIO = '';

export const createSocketiO = (server) => {
    socketIO = new Server(server, {
        cors: {
            origin: "*"
        }
    })
;    socketIO.on("connection" , (socket) => {
        socket.on('CREATEROOM' , async function(roomdata){ //roomid , creater , spender , orderid
            if(roomdata){
                var result = await createroom(roomdata?.roomid , roomdata?.creater , roomdata?.spender , roomdata?.orderid);
                socket.join(roomdata?.roomid.toString());
            }
        });

        socket.on('SENDMESSAGE' , async function(messagedata){   //from , to , message , roomid
            var msgobj = {
                'from' : messagedata?.from,
                'to' : messagedata?.to,
                'message' : messagedata?.message,
            }
            var result = await sendmessage(messagedata?.roomid , msgobj);
            socketEmit("NEWMESSAGE" , result , messagedata?.roomid)
        });

        socket.on('ONLEAVE' , async function(roomid){
            var msgobj = {
                'from' : '',
                'to' : '',
                'message' : "User Left the trade!"
            }
            var result = await lefttrade(roomid , msgobj)
            socketEmit("LEAVE" , result , roomid);
        })
    })
}


export const socketEmit = (type, message, roomid) => {
    try {
        socketIO.sockets.in(roomid.toString()).emit(type, message);
    } catch (err) {
    }
}