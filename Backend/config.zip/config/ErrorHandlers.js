const errorHandler = async (err, res) => {
    const response = {
        code: err.statusCode,
        message: err.message,
    };
    if (!response.code) {
        response.code = 400;
    }
    console.log("errrrrrrrrrr", err);
    return res
        .status(response.code)
        .json({ message: 'Oops,something went wrong', error: ' ' + err });
}

const sendResponse = async (res, status, statusCode, message, data) => {
    return res.json(encryptData({
        status, statusCode, message: message, data: data
    }));
}

module.exports = {
    sendResponse,
    errorHandler
}