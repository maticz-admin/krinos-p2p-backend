import axios from "axios";
import { NETWORK_BINANCE } from "./network";
import { json } from "body-parser";
// import keys from '../actions/config'


export const UseNetworkfromBinance = async(coin)=>{
//   var Configs = NETWORK_BINANCE.result;
//   if(!localStorage.getItem("NETWORK_BINANCE")){
//     try{
//       Configs = (await axios.get(keys.baseUrl+"cryptoapi/get/config"))?.data?.result
//       if(Configs)
//       localStorage.setItem("NETWORK_BINANCE",JSON.stringify(Configs));
//      }catch(e){
//      }
//   }else{
//     Configs = JSON.parse(localStorage.getItem("NETWORK_BINANCE"));
//   }

    let Configs = NETWORK_BINANCE.result;
//   if(!(Configs)){ Configs = NETWORK_BINANCE.result; }
    if(coin == "BNB.BSC"){
        let data = Configs.filter((item)=> (item.coin.toLocaleLowerCase() == String("BNB").toLocaleLowerCase()))
        let finaldata = data[0].networkList.filter((item)=> (item.network.toLocaleLowerCase() == String("BSC").toLocaleLowerCase()))
        return finaldata[0];
    }
    let data = Configs.filter((item)=> (item.coin.toLocaleLowerCase() == String(coin).toLocaleLowerCase()))
    let finaldata = data[0].networkList.filter((item)=> (item.network.toLocaleLowerCase() == String(coin).toLocaleLowerCase()))
    // const newArrayOfObj =  data[0].networkList.map(({
    //     name: label,
    //     network: value ,
    //     ...rest
    //   }) => ({
    //     label,
    //     value,
    //     ...rest
    //   }));
     return finaldata[0];
}

export const validatecryptoaddress = async(coin, address) => {
    try{
        const result = await UseNetworkfromBinance(coin);
        const regex = new RegExp(result?.addressRegex);
        return regex.test(address);
    }
    catch(E){
        return false;
    }
}