// import package
import mongoose from 'mongoose';

// import config
import config from './index';
import { CreateWallet } from '../controllers/bitgocheckcontroller';
import { EstimateGasForCoin, internalTransfer } from '../controllers/bitgo.controller';

// const dbConnection = (cb) => {
//     mongoose.connect(config.DATABASE_URL, {
//         useNewUrlParser: true,
//         useUnifiedTopology: true,
//         useCreateIndex: true,
//         useFindAndModify: false
//     }, (err, data) => {
//         if (err) {
//             setTimeout(() => {
//                 dbConnection(cb)
//             }, 1000)
//         } else {
//             return cb(true)
//         }
//     })
// }

// const dbConnection = (cb) => {
//     mongoose.connect("mongodb+srv://akashswamymaticz:1J1HMDnDKxjpvbry@cluster0.mokho.mongodb.net/EdafaceP2P", (err) => {
//         if (err) {
//             console.error('Database connection failed, retrying in 1 second...',error);
//             setTimeout(() => {
//                 dbConnection(cb);
//             }, 1000);
//         } else {
//             console.log('Database connected successfully');
//             return cb(true);
//         }
//     });
// };

async function dbConnection(cb) {
  try {
    console.log("mongo uri", config.DATABASE_URL);
    await mongoose.connect(config.DATABASE_URL);
    cb(true)
    console.log('Database connected successfully');
    // CreateWallet()
    // EstimateGasForCoin("hteth")
    // internalTransfer()
    
  } catch (error) {
    console.error('Database connection failed:', error);
    setTimeout(dbConnection, 1000); // Retry after 1 second if it fails
  }
}

export default dbConnection;