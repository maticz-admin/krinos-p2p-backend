require('dotenv').config(); // Import environment variables


let key = {};
const environment = "dem" //process.env.NODE_ENV ;
  console.log('environment----------', environment, environment === "production")
// empty string
if (environment === "demo") {
  console.log('production-----------------------')
  const API_URL = "https://krinosp2p-backend.maticz.in"//"https://api.aurexchange.com";
  const PORT = process.env.PORT_PROD;
  key = {
    SITE_NAME: process.env.SITE_NAME_PROD,
    secretOrKey: process.env.SECRET_OR_KEY_PROD,
    cryptoSecretKey: process.env.CRYPTO_SECRETKEY_PROD,
    DATABASE_URL: process.env.MONGO_DB_PROD,
    // "mongodb://NcgFbT:xMAgsK@139.162.66.242:53818/wXZeko",
    RUN_CRON: true,
    PORT: PORT,
    FRONT_URL: "https://krinosp2p.maticz.in", //"https://aurexchange.com",
    ADMIN_URL: "https://contorls.tossvtoss.com",         //"https://contorls.aurexchange.com",
    SERVER_URL: `${API_URL}`,
    IMAGE_URL: `${API_URL}`,
    RECAPTCHA_SECRET_KEY: process.env.RECAPTCHA_SECRET_KEY_PROD,
    IPN_URL: `${API_URL}/api/depositwebhook`,
    NUM_VERIFY: {
      API_KEY: "",
    },
    ETHRPCURL: "https://eth.llamarpc.com",//"https://broken-divine-borough.discover.quiknode.pro/51d7e894cc1b67046224cf5bcec96ad67506397d/",
    BINANCERPCURL: "",

    OWNERUSERID: process.env.OWNERUSERID_PROD,
    OWNERWALLET: process.env.OWNER_WALLET_PROD,
    OWNERPRIVATEKEY: process.env.OWNER_PRIVATE_KEY_PROD,
    //Sms Gateway
    // smsGateway: {
    //   TWILIO_ACCOUT_SID: "AC7654c3f84cd47fcd7f24498864a90b57",
    //   TWILIO_AUTH_TOKEN: "6edafaafac25137753acfa2f75593aba",
    //   TWILIO_PHONE_NUMBER: "+16402306943",
    //   TWILIO_SERVICE_SID: "VA0458e76ca85dddadfddcf5acad39709d",
    // },
    smsGateway: {
      TWILIO_ACCOUT_SID: process.env.SMS_GATEWAY_TWILIO_ACCOUT_SID_PROD,
      TWILIO_AUTH_TOKEN: process.env.SMS_GATEWAY_TWILIO_AUTH_TOKEN_PROD,
      TWILIO_SERVICE_SID: process.env.SMS_GATEWAY_TWILIO_SERVICE_SID_PROD,
      TWILIO_PHONE_NUMBER : process.env.TWILIO_PHONE_NUMBER_PROD
    },
    // SENDIN_BLUE_ADDRESS: {
    //     USER_NAME: "support",
    //     EMAIL: 'mailto:support@coingoldx.com',
    //     API_KEY: ' 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',
    // },

    // Email Gateway
    // emailGateway: {
    //     SENDGRID_API_KEY: 'G2_6DHfmSaWcrRQ1RxTHrQ',
    //     fromMail: "support@alwin.com",
    //     nodemailer: {
    //         host: "smtp.gmail.com",
    //         port: 587,
    //         secure: false, // true for 465, false for other ports
    //         auth: {
    //             user: 'ajith@britisheducationonline.org', // generated ethereal user
    //             pass: 'Ajith@97', // generated ethereal password
    //         },
    //     }
    // },

    IMAGE: {
      DEFAULT_SIZE: 1 * 1024 * 1024, // 1 MB,
      PROFILE_SIZE: 1 * 1024 * 1024, // 1 MB
      PROFILE_PATH: "public/profile",
      PROFILE_URL_PATH: "/profile",
      URL_PATH: "/images/profile/",
      KYC_PATH: "public/images/kyc",
      KYC_URL_PATH: "/images/kyc/",
      CMS_PATH: "public/images/cms/",
      CURRENCY_SIZE: 0.5 * 1024 * 1024, // 500 KB
      CURRENCY_PATH: "public/images/currency",
      CURRENCY_URL_PATH: "/images/currency/",
      DEPOSIT_PATH: "public/deposit",
      DEPOSIT_URL_PATH: "/deposit/",
      SETTINGS_URL_PATH: "public/settings",
      LAUNCHPAD_SIZE: 20 * 1024 * 1024, // 20 MB
      LAUNCHPAD_PATH: "public/launchpad",
      LAUNCHPAD_URL_PATH: "/launchpad/",
      SUPPORT_PATH: "public/images/support",
      SUPPORT_URL_PATH: "/images/support/",
      P2P_SIZE: 2 * 1024 * 1024, // 2 MB
      P2P_PATH: "public/p2p",
      P2P_URL_PATH: "/p2p/",
      ACCOUMENT_PATH: "public/images/anouncement",
      ACCOUMENT_URL_PATH: "/anouncement/",
      PROFILE_PATH2: "public/user_profile_img/",

    },
    WAZIRIX: {
      API: process.env.WAZIRIX_API_PROD, //using for orderplace
      SECRET: process.env.WAZIRIX_SECRET_PROD, //using for orderplace
    },

    NODE_TWOFA: {
      NAME: "KRINOS",
      QR_IMAGE:
        "https://chart.googleapis.com/chart?chs=166x166&chld=L|0&cht=qr&chl=",
    },
    COIN_GATE_WAY: {
      BTC: {
        URL: "http://45.79.42.88:3000",
      },
      LTC: {
        URL: "http://104.237.132.25:3000",
      },
      DOGE: {
        URL: "http://45.33.1.14:3000",
      },
      ETH: {
        URL: "http://173.230.156.107:3000",
        ADDRESS: process.env.ETH_ADDRESS_PROD,
        PRIVATE_KEY: process.env.ETH_PRIVATE_KEY_PROD
      },
      BNB: {
        URL: "https://bsc-dataseed.binance.org/",
        START_BLOCK: 0,
        DEPOSIT_URL:
          "https://api.bscscan.com/api?module=account&action=txlist&address=##USER_ADDRESS##&startblock=##START_BLOCK##&endblock=##END_BLOCK##&sort=asc&apikey=EWRUSHE7B64KNR5S5J7IQBT43PSTXTWHSI",
        DEPOSIT_TOKEN_URL:
          "https://api.bscscan.com/api?module=account&action=tokentx&address=##USER_ADDRESS##&startblock=##START_BLOCK##&endblock=##END_BLOCK##&sort=asc&apikey=EWRUSHE7B64KNR5S5J7IQBT43PSTXTWHSI",
        NETWORK_ID: 56,
        CHAIN_ID: 56,
        ADDRESS: process.env.BNB_ADDRESS_PROD,
        PRIVATE_KEY: process.env.BNB_PRIVATE_KEY_PROD,
      },
      XRP: {
        URL: "wss://s1.ripple.com",
        ADDRESS: process.env.XRP_ADDRESS_PROD,
        PRIVATE_KEY: process.env.XRP_PRIVATE_KEY_PROD
      },
      TRON: {
        FULLNODE: "https://api.trongrid.io",
        SOLIDITYNODE: "https://api.trongrid.io",
        EVENTSERVER: "https://api.trongrid.io",
        contractAddress: process.env.TRON_CONTYRACT_ADDRESS_PROD,
        PRIVATEKEY: process.env.TRON_PRIVATE_KEY_PROD,
        ADDRESS: process.env.TRON_ADDRESS_PROD,
        TRANSACTIONURL: "https://api.trongrid.io/v1/accounts/##USER_ADDRESS##/transactions?only_to=true&limit=50",
        TRANSACTIONCONTRACTURL:
          "https://api.trongrid.io/v1/accounts/##USER_ADDRESS##/transactions/trc20?limit=100&contract_address=##CONTRACT_ADDRESS##",
        DECIMAL: 100000000, //8
        TRONDECIMAL: 1000000, //6
        ADMINAMTSENTTOUSER: 10,
      },
    },

    coinGateway: {
      eth: {
        url: "http://139.162.1.152:3000",
        startBlock: 11504800,
        mode: "ropsten", // ropsten
        address: process.env.COIN_PAYMENT_GATEWAY_ADDRESS_PROD,
        privateKey: process.env.COIN_PAYMENT_PRIVATEKEY_PROD,
        etherscanUrl: "https://api.etherscan.io/api?", // https://api-ropsten.etherscan.io/api?
        ethDepositUrl:
          "https://api.etherscan.io/api?module=account&action=txlist&address=##USER_ADDRESS##&startblock=##START_BLOCK##&endblock=##END_BLOCK##&sort=asc&apikey=CSM5YXQG5MTE8XWM57UWH6DBXQRS8SQP3K",
        ethTokenDepositUrl:
          "https://api.etherscan.io/api?module=account&action=tokentx&address=##USER_ADDRESS##&startblock=##START_BLOCK##&endblock=##END_BLOCK##&sort=asc&apikey=CSM5YXQG5MTE8XWM57UWH6DBXQRS8SQP3K",
      },
      btc: {
        url: "http://3.1.6.100:3003",
      },
      tron: {
        fullNode: "https://api.trongrid.io",
        solidityNode: "https://api.trongrid.io",
        eventServer: "https://api.trongrid.io",
        contractAddress: process.env.TRON_CONTRACT_ADDRESS_2_PROD,
        privateKey:process.env.TRON_PRIVATE_KEY_2_PROD,
        // privateKey: "45365BE9280C6066E65857004F932DE9A90F7EF60387533D6AFFDB4A3608A2AC", // original privatekey
        address: process.env.TRON_ADDRESS_2_PROD,
        transactionUrl:
          "https://api.trongrid.io/v1/accounts/##USER_ADDRESS##/transactions?only_to=true&limit=50",
        transactionContractUrl:
          "https://api.trongrid.io/v1/accounts/##USER_ADDRESS##/transactions/trc20?limit=100&contract_address=##CONTRACT_ADDRESS##",
        decimal: 1000000, //18
        tronDecimal: 1000000, //6
        adminAmtSentToUser: 10,
      },
    },
    BINANCE_GATE_WAY: {
      // API_KEY: 'LohrjuucqdzFKCoNGm2Uku7aw9uaIh1jyVD5wAOxuZZP6uW4RBqbXCxdgiIB2GTr',
      API_KEY:process.env.BINANCE_GATE_WAY_API_KEY_PROD,
      // API_SECRET: 'qFNvYopTOmf9LBhgJvKDvuU46k5jCJoTOJTsRN2yxxesdspXjYpxdch3WMqFhZZD',
      API_SECRET:process.env.BINANCE_GATE_WAY_API_SECRET_PROD,
    },
    coinpaymentGateway: {
      PUBLIC_KEY: process.env.COIN_PAYMENT_GATEWAY_PUBLIC_KEY_PROD,
      // "9458d22b0afe1f705a6bff34232b482b383759a19773d280cbe98978da21fe72",
      PRIVATE_KEY: process.env.COIN_PAYMENT_GATEWAY_PRIVATE_KEY_PROD,
      // "1449dcd2e83623535753e5B8A0Ee05d9d418855f4ca3ceeb9251aB6Fd54a1CD7",
      IPN_SECRET: process.env.COIN_PAYMENT_IPN_SECRET_PROD,        //"testing",
      MERCHANT_ID: process.env.COIN_PAYMENT_MERCHANT_ID_PROD     // "c5079ace09de33613f7ca7aab790a658",
    },
    CLOUDINARY_GATE_WAY: {
      CLOUD_NAME: "",
      API_KEY: "",
      API_SECRET: "",
    },
    COINMARKETCAP: {
      API_KEY: "",
      PRICE_CONVERSION: "",
    },
  }
}
else {
  console.log('local-----------------------')
  const API_URL = "http://localhost";
  const PORT = process.env.PORT_DEV;
  key = {
    ETHRPCURL: process.env.ETHRPCURL_DEV,
    BINANCERPCURL: process.env.BINANCERPCURL_DEV,
    OWNERUSERID: process.env.OWNERUSERID_DEV,
    OWNERWALLET: process.env.OWNERWALLET,
    OWNERPRIVATEKEY: process.env.OWNERPRIVATEKEY_DEV,
    SITE_NAME: process.env.SITE_NAME_DEV,
    secretOrKey: process.env.SECRET_OR_KEY_DEV,
    cryptoSecretKey: process.env.CRYPTO_SECRETKEY_DEV,
    DATABASE_URL: process.env.MONGO_DB_DEV,
    // DATABASE_URL:  "mongodb+srv://murugavelraj:Dq0O4yMRaTPHw0ub@krinoswallet.9ifoe.mongodb.net/krinos-local",
    // "mongodb+srv://akashswamymaticz:1J1HMDnDKxjpvbry@cluster0.mokho.mongodb.net/EdafaceP2P", //"mongodb://aQNCde:LRYmcj@43.204.99.101:10382/FNpWAv" ,?retryWrites=true&w=majority&tls=true&tlsAllowInvalidCertificates=true,

    //CluxChange

    // DATABASE_URL: "mongodb://cluxdb:Fvdhcdcedhf6wed34sxdz@172.105.40.100:10730/cluxdb",
    // DATABASE_URL: "mongodb://clux:Password__2022__PasworD@23.239.23.84:10330/clux",
    RUN_CRON: false,
    PORT: PORT,
    FRONT_URL: "http://localhost:3000",
    ADMIN_URL: "http://localhost:3000/admin",
    SERVER_URL: `${API_URL}:${PORT}`,
    RECAPTCHA_SECRET_KEY: process.env.RECAPTCHA_SECRET_KEY_DEV,
    NUM_VERIFY: {
      API_KEY: "",
    },
    IPN_URL: `http://localhost:${PORT}/api/depositwebhook`,
    //Sms GateWay
    // smsGateway: {
    //   TWILIO_ACCOUT_SID: "AC4d78592207e69542cefd5388ea3993b8",
    //   TWILIO_AUTH_TOKEN: "c8d4b4d1b00406e5a906d0275d52a1b4",
    //   TWILIO_PHONE_NUMBER: "+12055390747",
    //   TWILIO_SERVICE_SID: "VA62d3e1146360cde9289bb8c26e098d1d",
    // },

    // smsGateway: {
    //   TWILIO_ACCOUT_SID: "AC3337f5849c8a649c1ffa248c8f71defb",
    //   TWILIO_AUTH_TOKEN: "19cf88a0907fdd72737418e4e4a749eb",
    //   TWILIO_PHONE_NUMBER: "+16067813169",
    //   TWILIO_SERVICE_SID: "VAa0d00c12c62fc4948baa3da924199766",
    // },
    smsGateway: {
      TWILIO_ACCOUT_SID: process.env.TWILIO_ACCOUT_SID_DEV,
      TWILIO_AUTH_TOKEN: process.env.TWILIO_AUTH_TOKEN_DEV,
      TWILIO_SERVICE_SID: process.env.TWILIO_SERVICE_SID_DEV,
      TWILIO_PHONE_NUMBER : process.env.TWILIO_PHONE_NUMBER_DEV
    },

    //EnailGateWay
    // emailGateway: {
    //     SENDGRID_API_KEY: 'G2_6DHfmSaWcrRQ1RxTHrQ',
    //     fromMail: "mailto:support@alwin.com",
    //     nodemailer: {
    //         host: "smtp.gmail.com",
    //         port: 587,
    //         secure: false, // true for 465, false for other ports
    //         auth: {
    //             user: 'mailto:ajith@britisheducationonline.org', // generated ethereal user
    //             pass: 'Ajith@97', // generated ethereal password
    //         },
    //     }
    // },

    IMAGE: {
      DEFAULT_SIZE: 1 * 1024 * 1024, // 1 MB,
      URL_PATH: "/images/profile/",
      PROFILE_SIZE: 1 * 1024 * 1024, // 1 MB
      PROFILE_PATH: "public/profile",
      PROFILE_URL_PATH: "/profile",

      ID_DOC_SIZE: 12 * 1024 * 1024, // 12 MB,
      KYC_PATH: "public/images/kyc",
      KYC_URL_PATH: "/images/kyc/",
      CMS_PATH: "public/images/cms/",

      CURRENCY_SIZE: 0.02 * 1024 * 1024, // 20 KB
      CURRENCY_PATH: "public/images/currency",
      CURRENCY_URL_PATH: "/images/currency/",
      DEPOSIT_PATH: "public/deposit",
      DEPOSIT_URL_PATH: "/deposit/",
      SETTINGS_URL_PATH: "public/settings",
      LAUNCHPAD_SIZE: 20 * 1024 * 1024, // 500 KB
      LAUNCHPAD_PATH: "public/launchpad",
      LAUNCHPAD_URL_PATH: "/launchpad/",
      SUPPORT_PATH: "public/images/support",
      SUPPORT_URL_PATH: "/images/support/",
      ACCOUMENT_PATH: "public/images/anouncement",
      ACCOUMENT_URL_PATH: "/images/anouncement/",

      P2P_SIZE: 2 * 1024 * 1024, // 2 MB
      P2P_PATH: "public/p2p",
      P2P_URL_PATH: "/p2p/",
      PROFILE_PATH2: "public/user_profile_img/"
    },

    WAZIRIX: {
      API: process.env.API_DEV,
      SECRET: process.env.SECRET_DEV
    },

    NODE_TWOFA: {
      NAME: "KRINOS",
      QR_IMAGE: "https://chart.googleapis.com/chart?chs=166x166&chld=L|0&cht=qr&chl=",
    },
    // smsGateway: {
    //   TWILIO_ACCOUT_SID: "AC7654c3f84cd47fcd7f24498864a90b57",
    //   TWILIO_AUTH_TOKEN: "6edafaafac25137753acfa2f75593aba",
    //   TWILIO_PHONE_NUMBER: "+16402306943",
    //   TWILIO_SERVICE_SID: "VA0458e76ca85dddadfddcf5acad39709d",
    // },
    // smsGateway: {
    //   TWILIO_ACCOUT_SID: "AC3337f5849c8a649c1ffa248c8f71defb",
    //   TWILIO_AUTH_TOKEN: "19cf88a0907fdd72737418e4e4a749eb",
    //   TWILIO_PHONE_NUMBER: "+16067813169",
    //   TWILIO_SERVICE_SID: "VAa0d00c12c62fc4948baa3da924199766",
    // },
    // smsGateway: {
    //   TWILIO_ACCOUT_SID: "ACc1dbb9b3537ce989aaf9d7a4ee579c06",
    //   TWILIO_AUTH_TOKEN: "9fd5b0247b8cce2957ac00989e46c8a7",
    //   TWILIO_PHONE_NUMBER: "+1720753-5030",
    //   TWILIO_SERVICE_SID: "VA16632de001e4aefb1dcb0d372663b5ed",
    // },
    smsGateway: {
      TWILIO_ACCOUT_SID: process.env.TWILIO_ACCOUT_SID_DEV,
      TWILIO_AUTH_TOKEN: process.env.TWILIO_AUTH_TOKEN_DEV,
      TWILIO_SERVICE_SID: process.env.TWILIO_SERVICE_SID_DEV,
      TWILIO_PHONE_NUMBER : process.env.TWILIO_PHONE_NUMBER_PROD
    },
    COIN_GATE_WAY: {
      BTC: {
        URL: "http://45.79.42.88:3000",
      },
      LTC: {
        URL: "http://104.237.132.25:3000",
      },
      DOGE: {
        URL: "http://45.33.1.14:3000",
      },
      ETH: {
        URL: "http://173.230.156.107:3000",
      },
      BNB: {
        URL: "https://data-seed-prebsc-1-s1.binance.org:8545",
        START_BLOCK: 0,
        DEPOSIT_URL:
          "https://api-testnet.bscscan.com/api?module=account&action=txlist&address=##USER_ADDRESS##&startblock=##START_BLOCK##&endblock=##END_BLOCK##&sort=asc&apikey=15YENF4YFTS1N8SWJWX8X4WTKTM17M8I49",
        DEPOSIT_TOKEN_URL:
          "https://api-testnet.bscscan.com/api?module=account&action=tokentx&address=##USER_ADDRESS##&startblock=##START_BLOCK##&endblock=##END_BLOCK##&sort=asc&apikey=15YENF4YFTS1N8SWJWX8X4WTKTM17M8I49",
        NETWORK_ID: 97,
        CHAIN_ID: 97,
        ADDRESS: process.env.ADDRESS_OF_BNB_DEV,
        PRIVATE_KEY: process.env.BNB_PRIVATE_KEY_DEV,
        // privateKey: 'U2FsdGVkX1+/WJmhPLIsNFWGGR4QO8trtIhrljMvR3opvf3DStEFHskqSBrNTwUHVOF2Y9/ddiVL7TDpYijbBMxsWX0OSddX4uM2X/BBhtD93s9G89xv7460U8ea7N4o',
      },
      XRP: {
        URL: "wss://s1.ripple.com",
        ADDRESS: process.env.ADDRESS_OF_XRP_DEV,
        PRIVATE_KEY: process.env.XRP_PRIVATE_KEY_DEV,
      },
      ETC: {
        URL: "http://173.255.221.129:3000",
      },
      TRON: {
        FULLNODE: "https://api.shasta.trongrid.io",
        SOLIDITYNODE: "https://api.shasta.trongrid.io",
        EVENTSERVER: "https://api.shasta.trongrid.io",
        contractAddress: process.env.TRON_CONTRACT_ADDRESS_DEV,
        PRIVATEKEY: process.env.TRON_PRIVATE_KEY_DEV,
        ADDRESS: process.env.TRON_ADDRESS_DEV,
        TRANSACTIONURL:
          "https://api.shasta.trongrid.io/v1/accounts/##USER_ADDRESS##/transactions?only_to=true&limit=50",
        TRANSACTIONCONTRACTURL:
          "https://api.shasta.trongrid.io/v1/accounts/##USER_ADDRESS##/transactions/trc20?limit=100&contract_address=##CONTRACT_ADDRESS##",
        DECIMAL: 100000000, //8
        TRONDECIMAL: 1000000, //6
        ADMINAMTSENTTOUSER: 2.00004,
      },
    },

    coinGateway: {
      eth: {
        url: "http://139.162.1.152:3000",
        startBlock: 11504800,
        address: process.env.COIN_PAYMENT_GATEWAY_DEV,
        privateKey: process.env.COIN_PAYMENT_PRIVATEKEY_DEV,
        etherscanUrl: "https://api.etherscan.io/api?", // https://api-ropsten.etherscan.io/api?
        ethDepositUrl:
          "https://api-ropsten.etherscan.io/api?module=account&action=txlist&address=##USER_ADDRESS##&startblock=##START_BLOCK##&endblock=##END_BLOCK##&sort=asc&apikey=CSM5YXQG5MTE8XWM57UWH6DBXQRS8SQP3K",
        ethTokenDepositUrl:
          "https://api-ropsten.etherscan.io/api?module=account&action=tokentx&address=##USER_ADDRESS##&startblock=##START_BLOCK##&endblock=##END_BLOCK##&sort=asc&apikey=CSM5YXQG5MTE8XWM57UWH6DBXQRS8SQP3K",
      },
      btc: {
        url: process.env.BTC_BASE_URL_DEV,
      },
      tron: {
        fullNode: "https://api.shasta.trongrid.io",
        solidityNode: "https://api.shasta.trongrid.io",
        eventServer: "https://api.shasta.trongrid.io",
        contractAddress: process.env.TRON_CONTRACT_ADDRESS_2_DEV,
        privateKey: process.env.TRON_PRIVATE_KEY_2_DEV,
        address: process.env.TRON_ADDRESS_2_DEV,
        transactionUrl:
          "https://api.shasta.trongrid.io/v1/accounts/##USER_ADDRESS##/transactions?only_to=true&limit=50",
        transactionContractUrl:
          "https://api.shasta.trongrid.io/v1/accounts/##USER_ADDRESS##/transactions/trc20?limit=100&contract_address=##CONTRACT_ADDRESS##",
        decimal: 100000000, //8
        tronDecimal: 1000000, //6
        adminAmtSentToUser: 2.00004,
      },
    },

    BINANCE_GATE_WAY: {
      API_KEY: "",
      API_SECRET: "",
      // API_KEY: 'LohrjuucqdzFKCoNGm2Uku7aw9uaIh1jyVD5wAOxuZZP6uW4RBqbXCxdgiIB2GTr',
      // API_SECRET: 'qFNvYopTOmf9LBhgJvKDvuU46k5jCJoTOJTsRN2yxxesdspXjYpxdch3WMqFhZZD',
    },
    coinpaymentGateway: {
      PUBLIC_KEY: process.env.PUBLIC_KEY_DEV,
      // "9458d22b0afe1f705a6bff34232b482b383759a19773d280cbe98978da21fe72",
      PRIVATE_KEY: process.env.PRIVATE_KEY_DEV,
      // "1449dcd2e83623535753e5B8A0Ee05d9d418855f4ca3ceeb9251aB6Fd54a1CD7",
      IPN_SECRET: process.env.IPN_SECRET_DEV,        //"testing",
      MERCHANT_ID: process.env.MERCHANT_ID_DEV   // "c5079ace09de33613f7ca7aab790a658",
    },
    CLOUDINARY_GATE_WAY: {
      CLOUD_NAME: "",
      API_KEY: "",
      API_SECRET: "",
    },
    COINMARKETCAP: {
      API_KEY: "",
      PRICE_CONVERSION: "",
    },
  };
}

export default {
  ...key,
  emailGateway : require("./smtpConfig.json"),
}