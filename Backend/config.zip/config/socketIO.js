// import package
import { Server } from "socket.io";
import {
  createroom,
  lefttrade,
  sendmessage,
  userstatus,
} from "../controllers/P2PCONTROLLER/OrderchatController";

let socketIO = "";

export const createSocketIO = (server) => {
  try {
    socketIO = new Server(server, {
      cors: {
        origin: "*",
      },
    });

    socketIO.on("connection", (socket) => {
      socket.on("CREATEROOM", function (userId) {
        if (userId) {
          socket.join(userId.toString());
        }
      });

      /**
       * Pending Order
       * toUserId, pairid, result
       */
      socket.on("pendingOrder", (data) => {
        try {
          let respData = {
            pairId: data.pairId,
            result: data.result,
          };
          socketEmitOne("userPendingOrder", respData, data.toUserId);
        } catch (err) {}
      });

      /**
       * Filled Order
       * toUserId, pairId, result
       */
      socket.on("filledOrder", (data) => {
        try {
          let respData = {
            pairId: data.pairId,
            result: data.result,
          };
          socketEmitOne("userFilledOrder", respData, data.toUserId);
        } catch (err) {}
      });

      /**
       * Order History
       * toUserId, pairId, result
       */
      socket.on("orderHistory", (data) => {
        try {
          let respData = {
            pairId: data.pairId,
            result: data.result,
          };
          socketEmitOne("userOrderHistory", respData, data.toUserId);
        } catch (err) {}
      });

      /**
       * Order Book
       * pairId, result
       */
      socket.on("orderBook", (data) => {
        socketEmitAll("userOrderBook", data);
      });

      /**
       * Order Book
       * pairId, result
       */
      socket.on("recentTrades", (data) => {
        socketEmitAll("userRecentTrade", data);
      });

      /**
       * Update Balance For Maker
       * pairId, price, userId, filledQuantity, buyorsell
       */
      socket.on("makerSpotBalance", (data) => {
        data["type"] = "maker";
        // updateSpotBalance(data)
      });

      /**
       * Update Balance For Taker
       * pairId, price, userId, filledQuantity, buyorsell
       */
      socket.on("takerSpotBalance", (data) => {
        data["type"] = "taker";
        // updateSpotBalance(data)
      });

      /**
       * Binance Price List
       * currencyList
       */
      socket.on("binancePriceList", (data) => {
        // USDConvention(data)
      });

      /**
       * Binance Ticker
       * pairId, userId
       */
      socket.on("binanceTicker", (data, callback) => {
        // ticker24hrs(data, callback)
      });

      /**
       * Binance Price List
       * currencyList
       */
      socket.on("orderBookByPairId", (data) => {
        // orderBookByPairId(data)
      });

      /**
       * Balance Update at Cancel Order
       * userId, pairId, price, quantity, buyorsell
       */
      socket.on("updateBalance", (data) => {
        // updateBalance(data)
      });

      socket.on("disconnecting", () => {});

      //Chatroom
      socket.on("CREATECHATROOM", async function (roomdata) {
        //roomid , creater , spender , orderid
        if (roomdata) {
          var result = await createroom(
            roomdata?.roomid,
            roomdata?.creater,
            roomdata?.spender,
            roomdata?.orderid
          );
          socket.join(roomdata?.toString());
          socketEmit("CHAT", result, roomdata?.roomid);
        }
      });

      socket.on("SENDMESSAGE", async function (messagedata) {
        //from , to , message , roomid
        var msgobj = {
          from: messagedata?.from,
          to: messagedata?.to,
          message: messagedata?.message,
          time: messagedata?.time,
        };
        var result = await sendmessage(
          messagedata?.roomid,
          msgobj,
          messagedata?.image
        );
        socketEmit("NEWMESSAGE", result, messagedata?.roomid);
      });

      socket.on("CHECKPING", async function (data) {
        socketEmit("PING", data, data?.roomid);
      });
      socket.on("ONLEAVE", async function (roomid) {
        var msgobj = {
          from: "",
          to: "",
          message: "User Left the trade!",
        };
        var result = await lefttrade(roomid, msgobj);
        socketEmit("LEAVE", result, roomid);
      });

      // socket.on('USERSTATUS' , async function(data){console.log("userstatus" , data);
      //     socketEmit("PING" , data , data?.roomid);
      // })
    });
  } catch (err) {
    console.log("adsdasdasdas", err);
  }
};

export const socketEmitAll = (type, data) => {
  try {
    socketIO.emit(type, data);
  } catch (err) {}
};

export const socketEmitOne = (type, data, userId) => {
  try {
    socketIO.sockets.in(userId.toString()).emit(type, data);
  } catch (err) {}
};

export const socketEmitChat = (type, data, userid) => {
  try {
    socketIO.emit(type, data, userid);
  } catch (err) {}
};

export const socketEmit = (type, message, roomid) => {
  try {
    //sockets.in(roomid.toString()).emit
    socketIO.emit(type, message, roomid);
  } catch (err) {}
};

export const socketEmitofferrequest = (type, data, userid) => {
  try {
    socketIO.sockets.in(userid.toString()).emit(type, data);
    // socketIO.emit(type, data, userid)
  } catch (err) {}
};
