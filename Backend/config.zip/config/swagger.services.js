// swagger.js
const swaggerJsdoc = require('swagger-jsdoc');
const swaggerUi = require('swagger-ui-express');

// Swagger definition
const swaggerDefinition = {
  openapi: '3.0.0', // Specify OpenAPI version
  info: {
    title: 'EdaFaceP2P', // Your API title
    version: '1.0.0', // Your API version
    description: 'P2P', // Your API description
  },
  components: {
    securitySchemes: {
      BearerAuth: {
        type: 'http',
        scheme: 'bearer',
        bearerFormat: 'JWT',
      },
    },
  },
  security: [
    {
      BearerAuth: [],
    },
  ],
  servers: [
    {
      url: 'http://localhost:2053', // Your API server URL
      description: 'Development server',
    },
  ],
};

// Options for the swagger docs
const options = {
  swaggerDefinition,
  apis: [
    './Swagger/p2pswagger.js',
    './Swagger/user.Swagger.js',
    './Swagger/Userkyc.swagger.js',
    './Swagger/usercontrol.swagger.js',
    './Swagger/P2PAdminSwagger.js',
    './Swagger/adminControlSwagger.js'
  ],
};

const swaggerSpec = swaggerJsdoc(options);

module.exports = {
  swaggerUi,
  swaggerSpec,
};
